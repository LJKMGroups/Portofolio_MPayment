-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 07 Mei 2017 pada 05.52
-- Versi Server: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `customer`
--

CREATE TABLE `customer` (
  `nama_depan` varchar(100) NOT NULL,
  `nama_belakang` varchar(11) NOT NULL,
  `no_hp` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `customer`
--

INSERT INTO `customer` (`nama_depan`, `nama_belakang`, `no_hp`, `email`, `tgl_lahir`, `alamat`) VALUES
('Muhammad Habib', 'Ulil Albaab', '085655556978', 'muhammadhabibulilalbaab@gmail.com', '2017-02-13', 'Batankrajan'),
('n', 'm', '085655556978', 'muhammadhabibulilalbaab@gmail.com', '2017-02-06', 'Batankrajan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `username` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `img` varchar(1000) NOT NULL,
  `password` varchar(500) NOT NULL,
  `level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`username`, `nama`, `img`, `password`, `level`) VALUES
('demo', 'Demo', '', 'fe01ce2a7fbac8fafaed7c982a04e229', 1),
('habibulilalbaab', 'Albaab Muhammad', 'localhost/login_dashboard/img/stats.png', '6dce8a2e4500807ce124e1d43b4c789d', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `product`
--

CREATE TABLE `product` (
  `nama_produk` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `harga_produk` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `product`
--

INSERT INTO `product` (`nama_produk`, `kode_produk`, `harga_produk`) VALUES
('k', '6yt', '69900'),
('kh', '66', '7'),
('mm', '7', '77'),
('u', 't65', '1000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`nama_depan`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`nama_produk`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
