-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 07 Mei 2017 pada 05.52
-- Versi Server: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `m-pulsa`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_pln`
--

CREATE TABLE `order_pln` (
  `id_pln` int(11) NOT NULL,
  `nomor` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `meter_pln` varchar(100) NOT NULL,
  `nominal` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `order_pln`
--

INSERT INTO `order_pln` (`id_pln`, `nomor`, `email`, `meter_pln`, `nominal`, `status`) VALUES
(7, '0', 'muhammadhabibulilalbaab@gmail.com', '7', '1', 0),
(8, '085655556978', 'muhammadhabibulilalbaab@gmail.com', '976', '1', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_pulsa`
--

CREATE TABLE `order_pulsa` (
  `id_order` int(11) NOT NULL,
  `nomor` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `provider` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `order_pulsa`
--

INSERT INTO `order_pulsa` (`id_order`, `nomor`, `email`, `provider`, `status`) VALUES
(20, '088888', 'muhalalbaab@gmail.com', '4', 0),
(21, '088888', 'muhalalbaab@gmail.com', '4', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_voucher`
--

CREATE TABLE `order_voucher` (
  `id_voucher` int(11) NOT NULL,
  `nomor` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `voucher` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `order_voucher`
--

INSERT INTO `order_voucher` (`id_voucher`, `nomor`, `email`, `voucher`, `status`) VALUES
(1, '085655556978', 'muhammadhabibulilalbaab@gmail.com', '1', 1),
(2, '98634779', 'muhsggy@gmail.com', '1', 0),
(3, '98634779', 'muhsggy@gmail.com', '1', 0),
(4, '085', 'khk@m.n', '1', 0),
(5, '89682896', 'muhammadhabibulilalbaab@gmail.com', '1', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `provider`
--

CREATE TABLE `provider` (
  `id_provider` int(11) NOT NULL,
  `provider` varchar(100) NOT NULL,
  `harga_beli` double NOT NULL,
  `harga_jual` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `provider`
--

INSERT INTO `provider` (`id_provider`, `provider`, `harga_beli`, `harga_jual`) VALUES
(1, 'INDOSAT', 4900, 5000),
(2, 'INDOSAT', 9900, 10000),
(3, 'INDOSAT', 25900, 26000),
(4, 'INDOSAT', 50900, 51000),
(5, 'INDOSAT', 990900, 100000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `token_pln`
--

CREATE TABLE `token_pln` (
  `id_pln` int(11) NOT NULL,
  `token_pln` varchar(100) NOT NULL,
  `harga_beli` double NOT NULL,
  `harga_jual` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `token_pln`
--

INSERT INTO `token_pln` (`id_pln`, `token_pln`, `harga_beli`, `harga_jual`) VALUES
(1, 'TOKEN PLN', 25500, 26000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `voucher`
--

CREATE TABLE `voucher` (
  `id_voucher` int(11) NOT NULL,
  `jenis_voucher` varchar(100) NOT NULL,
  `harga_beli` double NOT NULL,
  `harga_jual` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `voucher`
--

INSERT INTO `voucher` (`id_voucher`, `jenis_voucher`, `harga_beli`, `harga_jual`) VALUES
(1, 'GARENA', 9900, 10000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `order_pln`
--
ALTER TABLE `order_pln`
  ADD PRIMARY KEY (`id_pln`);

--
-- Indexes for table `order_pulsa`
--
ALTER TABLE `order_pulsa`
  ADD PRIMARY KEY (`id_order`);

--
-- Indexes for table `order_voucher`
--
ALTER TABLE `order_voucher`
  ADD PRIMARY KEY (`id_voucher`);

--
-- Indexes for table `provider`
--
ALTER TABLE `provider`
  ADD PRIMARY KEY (`id_provider`);

--
-- Indexes for table `token_pln`
--
ALTER TABLE `token_pln`
  ADD PRIMARY KEY (`id_pln`);

--
-- Indexes for table `voucher`
--
ALTER TABLE `voucher`
  ADD PRIMARY KEY (`id_voucher`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order_pln`
--
ALTER TABLE `order_pln`
  MODIFY `id_pln` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `order_pulsa`
--
ALTER TABLE `order_pulsa`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `order_voucher`
--
ALTER TABLE `order_voucher`
  MODIFY `id_voucher` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `provider`
--
ALTER TABLE `provider`
  MODIFY `id_provider` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `token_pln`
--
ALTER TABLE `token_pln`
  MODIFY `id_pln` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `voucher`
--
ALTER TABLE `voucher`
  MODIFY `id_voucher` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
